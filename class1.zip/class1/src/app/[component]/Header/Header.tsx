
import Nav from "../Nav/Nav"
export default function Header() {
  return (
<section  className="Sub-header">

<h1>About Us</h1>
</section>
  )
}
