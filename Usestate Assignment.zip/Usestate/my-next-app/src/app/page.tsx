'use client'
import React, { useState } from 'react';
import './globals.css'

export default function Page() {
  const [names, setNames] = useState(['Aaniq', 'Hamza', 'Ali', 'Unknown', 'Farooq']);
  const [curIndex, setCurIndex] = useState(0);

  const nextItem = () => {
    setCurIndex((prevIndex) => {
      const nextIndex = prevIndex + 1;
      return nextIndex < names.length ? nextIndex : 0;
    });
  };

  const prevItem = () => {
    setCurIndex((prevIndex) => {
      const newIndex = prevIndex - 1;
      return newIndex >= 0 ? newIndex : names.length - 1;
    });
  };

  return (
    <div className='body' >
<button className="button-33" role="button" onClick={prevItem}>Previous </button>

      {/* <button class="button-33" >Previous</button> */}
      <span className="span1">{names[curIndex]}</span>
      {/* <button onClick={nextItem}>Next</button> */}
      <button className="button-33" role="button" onClick={nextItem}>Next </button>
    </div>
  );
}
